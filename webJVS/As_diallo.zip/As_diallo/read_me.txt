
(*********************************************************************)

(*                                                                   *)

(*                           JS                                      *)

(*                                                                   *)

(*     Projet : Td1(exo1,exo2)                                       *)

(*  Auteur : Diallo Mohamed                                          *)

(*                                                                   *)
(*                                  D.U.T informatique A.S 2017/2018 *)

(*                                  IUT Charlemagne                  *)

(*                                  Universite de Lorraine           *)

(*                                                                   *)
(*********************************************************************)


A noter que chaque exercice est accompagn� d'un programme de test, et est comment� avec une synthaxe "Qnum_question)", d'ou la simplicit� de lecture .

Aussi dans le dossier, vous avez :
 * le fichier read_me
 * les fichiers td1,td2 et leurs pages web pour tester

Cordialement,

