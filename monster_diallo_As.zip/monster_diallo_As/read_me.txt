
(*********************************************************************)

(*                                                                   *)

(*                           Js                                      *)

(*                                                                   *)

(*     Projet : Monster                                              *)

(*  Auteur : Diallo Mohamed                                          *)

(*                                                                   *)
(*                                  D.U.T informatique A.S 2017/2018 *)

(*                                  IUT Charlemagne                  *)

(*                                  Universite de Lorraine           *)

(*                                                                   *)
(*********************************************************************)


� noter que l'exercice est accompagn� d'un certain nombre de commentaires, qui sont fonction de l'ordre dans lequel est trait� le projet.

Aussi, le code ne fonctionne dans le navigateur, que si l'ordi est connect� � internet.

Sans oublier, le soin pris pour indenter le code ....

Cordialement,

