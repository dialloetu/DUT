

import java.util.Arrays;

/**
 * Reponse du serveur POP3
 * @author Diallo Mohamed
 */
public class Response {
	
    private Boolean ok;             // status OK 
    private String message;         // message
    private String corps;            // informations supplementaires
    private String[] corpsLignes;     // comme le corps, mais ligne par ligne
    private POP3Exception POP3Exception;
    
    /**
     * constructeur
     * @param ok
     * @param message
     * @param corpsLignes
     */
    public Response(boolean ok, String message, String[] corpsLignes) {
        this.ok = ok;
        this.message = message;
        this.corpsLignes = corpsLignes;
        this.corps = Utils.textFromLines(this.corpsLignes);
    }
    
    /**
     * second constructeur
     * @param raw
     * @param longueur
     * @throws POP3Exception 
     */
    public Response(char[] raw, int longueur) throws POP3Exception {
        String response = new String(raw, 0, longueur);
        String[] lignes = response.split("\r\n");
        
        if (lignes.length == 0) {
            throw new POP3Exception("Aucune réponse du serveur");
        } else if (lignes.length == 1 && !response.endsWith("\r\n")) {
            throw new POP3Exception("Réponse uniligne mal terminée" + response);
        } else if (lignes.length > 1 && !response.endsWith("\r\n.\r\n")) {
            throw new POP3Exception("Réponse multiligne mal terminée" + response);
        }
        
        String l1 = lignes[0];
        int entier = l1.indexOf(" ");
        
        // status
        String status = l1.substring(0, entier);
        boolean isOk;
        if (status.equals("+OK")) {
            this.ok = true;
        } else if (status.equals("-ERR")) {
            this.ok = false;
        } else {
            throw new POP3Exception("Réponse mal formatée: " + response);
        }
        
        // message
        this.message = l1.substring(entier+1);
        
        // corps (peut etre vide)
        if (lignes.length > 1) {
            this.corpsLignes = Arrays.copyOfRange(lignes, 1, lignes.length-1);
        } else {
            this.corpsLignes = new String[0];
        }
        this.corps = Utils.textFromLines(this.corpsLignes);
    }
    
    /**
    * @return boolean
    * */
    public boolean isOK() {
        return this.ok;
    }
    
    /**
    * @return message
    * */
    public String getMessage() {
        return this.message;
    }
    
    /**
    * @return corps
    * */
    public String getBody() {
        return this.corps;
    }
    
    /**
    * @return corpsLignes
    * */
    public String[] getBodyLines() {
        return this.corpsLignes;
    }
    
    /**
    * @return status
    * */
    public String getStatus() {
        return (this.ok) ? "OK" : "Erreur";
    }
    
    @Override
    public String toString() {
        return this.getStatus() + " => " + this.message + " (" + this.getBody() +")";
    }
}
