

import java.util.Arrays;
import java.util.Iterator;

/**
 * Methodes utilitaires ou suplementaires
 * @author Diallo Mohamed
 */
public class Utils {

    /**
     * delimiteur est \n
     * @param lignes
     * @return 
     */
    static public String textFromLines(String[] lignes) {
        Iterator<String> iterator = Arrays.asList(lignes).iterator();
        StringBuilder construct = new StringBuilder("");
        
        while (iterator.hasNext()) {
            construct.append(iterator.next());
            if (!iterator.hasNext()) {
              break;                  
            }
            construct.append("\n");
        }
        
        return construct.toString();
    }
}
