

/**
 * Exception lors de consultation des messages et reception de reponses
 * @author Diallo Mohamed
 */
public class POP3Exception extends Exception {

    public POP3Exception (Response response) {
        super(response.getMessage() + " " + response.getBody());
    }
    
    public POP3Exception(String message) {
        super(message);
    }    
    
}
