

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * POP3 Client
 * @author Diallo Mohamed
 */
public class Client {
    private ConsoleInterface console;               // interface utilisateur
    private Socket socket;                          // TCP socket
    private SocketAddress sock_address;                  // addresse + port
    private BufferedReader buf_netin;                   // socket d'entre
    private BufferedWriter buf_netout;                  // socket de sortie
    private HashMap<Integer, Message> HM_messages;     // messages stocke localement
    private String chaineControl;
    
    private static final int TIMEOUT = 2000;        // le fameux socket timeout
    private static final int REPONSE_MAX_SIZE = 512;
    
    // Les commandes POP3
    public final static ArrayList<Pattern> PATTERNS = new ArrayList<Pattern>() {
        {
            add(Pattern.compile("^help$"));
            add(Pattern.compile("^connect (25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}(\\s\\d+)?$"));
            add(Pattern.compile("^auth \\w+ \\w+$"));
            add(Pattern.compile("^stat$"));
            add(Pattern.compile("^collect$"));
            add(Pattern.compile("^list$"));
            add(Pattern.compile("^read \\d+$"));
            add(Pattern.compile("^quit$"));
        }
    };
    
    public Client() {
        this.console = new ConsoleInterface("pop3 > ", PATTERNS);
        this.sock_address = null;
        this.socket = null;
        this.buf_netin= null;
        this.buf_netout = null;
        this.HM_messages = new HashMap<>();
    }
    
    /**
     * attend une reponse du POP3 serveprivate String chaineControl;r
     * @return
     * @throws IOException
     * @throws POP3Exception 
     */
    private Response getResponse() throws IOException, POP3Exception {
        char[] raw = new char[REPONSE_MAX_SIZE];
        int longueur = 0;
        try {
            longueur = this.buf_netin.read(raw);
        } catch(IOException ex) {
            throw new IOException("Impossible de récupérer la réponse du serveur: " + ex);
        }
        Response response = new Response(raw, longueur);
        return response;
    }
    
    /**
     * Leve une exception si le status de la reponse n'est pas OK
     * @return
     * @throws IOException
     * @throws POP3Exception 
     */
    private Response getResponseOrException() throws IOException, POP3Exception {
        Response response = this.getResponse();
        if (!response.isOK()) {
            throw new POP3Exception(response);
        }
        return response;
    }
    
    /**
     * envoi une commande au pop3 server
     * etablissment de la connexion tcp
     * @param command
     * @throws IOException
     * @throws POP3Exception 
     */
    private void sendCommand(String command) throws IOException, POP3Exception {
        if (!this.isConnected()) {
            throw new POP3Exception("Vous n'êtes pas connecté au serveur");
        }
        
        this.buf_netout.write(command + "\n");
        this.buf_netout.flush();
    }
    
    /**
     * methode principale
     * @note too lazy to do a command pattern
     */
    public void run() {
		System.out.println("(*********************************************************************)");
		System.out.println("(*                             BIENVENUE                             *)");
        System.out.println("(*********************************************************************)");
        System.out.println("	Tapez \"help\" pour afficher la liste des commandes");
        
        while (true) {
            Command command = this.console.getCommand();
            String action = command.getAction();
            String[] params = command.getParams();

            switch (action) {
                case "help": this.help(params); break;
                case "connect": this.runCommand(action, params, false, "Erreur lors de la connection au serveur"); break;
                case "auth": this.runCommand(action, params, true, "Erreur lors de l'authentification"); break;
               // case "apop": this.runCommand(action, params, true, "Erreur lors de l'authentification"); break;
                case "stat": this.runCommand(action, params, true, "Erreur lors de la récupération des statistiques du serveur"); break;
                case "collect": this.runCommand(action, params, true, "Erreur lors de la récupération de vos emails"); break;
                case "list": this.runCommand(action, params, true, "Erreur lors de l'affichage de vos messages"); break;
                case "read": this.runCommand(action, params, true, "Impossible de la lecture de l'un de vos messages"); break;
                case "quit": this.runCommand(action, params, false, "Erreur lors de la terminaison du client"); break;
                default: System.out.println("Commande non reconnue");
            }
        }
    }
    
    /**
     * Invoque la commande du client
     * @param methodName
     * @param params
     * @param needConnection leve une eception si le client doit etre connecter au serveur pour executer la commande
     * @param errorMessage 
     */
    private void runCommand(String methodName, String[] params, boolean needConnection, String errorMessage) {
        if (needConnection && !this.isConnected()) {
            System.err.println("Vous devez vous connecter à un serveur pour exécuter cette commande");
            return;
        }
        Method method = null;
        try {
            method = getClass().getDeclaredMethod(methodName, String[].class);
        } catch (NoSuchMethodException|SecurityException ex) {
            System.err.println("Impossible d'invoquer la méthode: " + methodName);
        }
        try {
            method.invoke(this, (Object) params);
        } catch (Exception ex) {
            if (ex.getCause() instanceof IOException || ex.getCause() instanceof POP3Exception) {
                System.err.println(errorMessage + ": " + ex.getCause());
            } else {
                ex.printStackTrace();
                System.exit(1);
            }
        }
    }
    
    /**
     * Affichage de l'aide pour l'utilisateur
     * @param params 
     */
    public void help(String[] params) {
		System.out.println("(*********************************************************************)");
		System.out.println("                         Commandes disponibles:                        ");
        System.out.println("(*********************************************************************)");
        System.out.print("\n\n");
        System.out.println("-  help: affiche l'aide");
        System.out.println("(*********************************************************************)");
		System.out.println("                             Tâche Numéro :    1                       ");
        System.out.println("(*********************************************************************)");
        System.out.println("-  Assurez-vous d'avoir lancer le client POP3 sur un autre terminal ");
        System.out.println("	 example : Java PopServer  ");
        System.out.println("(*********************************************************************)");
		System.out.println("                             Tâche Numéro :    2                       ");
        System.out.println("(*********************************************************************)");
        System.out.println("-  Maintenant sur ce termianl, executer les instructions ci-dessous ");
        System.out.println("-  connect host <port>: connexion à un hôte/port ");
        System.out.println("- 	exemple : connect 127.0.0.1 1100 ");
        System.out.println("- auth user pass: authentification d'un utilisateur ");
        System.out.println("- 	exemple : auth alice 123456 ");
        System.out.println("- stat: statistique sur le stockage des mails de votre compte, ");
        System.out.println("- 	 exemple : stat ");
        System.out.println("- collect: récupère les emails du compte (suppression en cas de succès) ");
        System.out.println("- 	 exemple : collect ");
        System.out.println("- list: liste les messages stockés localement, exemple : list ");
        System.out.println("- read id: lis le contenu d'un mail, exempke : read 2 ");
        System.out.println("- quit: quitte le programme, exemple : quit ");
        System.out.println("(*********************************************************************)");
    }
    
    /**
     * Connexion du client au serveur 
     * (Seulement le mode TCP est permis )
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void connect(String[] params) throws IOException, POP3Exception {
        System.out.println("connexion en cours ...\n");
        String host = (params.length == 0) ? "127.0.0.1" : params[0];
        short port = (params.length == 2) ?  Short.valueOf(params[1]) : (short) 1100;
        this.sock_address = new InetSocketAddress(host, port);
        System.out.println("Host: " + host + ", Port: " + port);
        this.disconnect(); 
        this.socket = new Socket();
        this.socket.setSoTimeout(TIMEOUT);
        this.socket.connect(this.sock_address);
        this.buf_netout = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
        this.buf_netin = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
        this.getResponseOrException();
        System.out.println("\nConnexion réussie !");
    }
    
    /**
     * Authentification pour un utilisateur et son mot de passe 
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void auth(String[] params) throws IOException, POP3Exception {
        if (params.length < 2) {
            System.err.println("Vous devez fournir un nom d'utilisateur et un mot de passe (voir la commande help)");
            return;
        }
        String user = params[0];
        String pass = params[1];
        this.sendCommand("USER " + user);
        this.getResponseOrException();
        this.sendCommand("PASS " + pass);
        this.getResponseOrException();
        System.out.println("Authentification réussie !");
    }
    
    
    /**
     * Authentification par apop
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     
    private void apop(String[] params) throws IOException, POP3Exception {
            try {
        String user = params[0];
        String pass = params[1];
        String timbre = null;
            byte[] encoded = Files.readAllBytes(Paths.get(user + "/password.txt"));
             //Create the MD5 to compare with the server
                String encrypted = "";   
                String password = new String(encoded, "UTF-8");
                System.out.println(chaineControl + " " + password);
                chaineControl = chaineControl.concat(new String(encoded, "UTF-8"));
                byte[] str_code = MessageDigest.getInstance("MD5").digest(chaineControl.getBytes());
                for (byte b : str_code) {
                    encrypted = encrypted + Integer.toHexString(b & 0xFF);
                }
                if (pass.equals(encrypted)) {
					this.sendCommand("USER " + user);
					this.getResponseOrException();
					this.sendCommand("PASS " + pass);
					this.getResponseOrException();
                    System.out.println("Authentification réussie !");
                } else {
                    System.out.println("Authentification Fail !");
                }             
            } catch (IOException | IndexOutOfBoundsException ex) {
                System.err.println(ex.getMessage());
                if (ex instanceof IndexOutOfBoundsException) {
                    System.err.println("APOP requires 2 parameters : user and password");
                }
                System.out.println("Authentification Fail !");
            } catch (NoSuchAlgorithmException ex) {
                //Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        System.out.println("Authentification wrong !");
     }
    */
    
    /**
     * Affichage des statistiques de stockage des messages
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void stat(String[] params) throws IOException, POP3Exception {
        this.sendCommand("STAT");
        Response response = this.getResponseOrException();
        String[] infos = response.getMessage().split(" ");
        if (infos.length != 2) {
            throw new POP3Exception("Réponse statistique mal formaté: " + response.getMessage());
        }
        String nb = infos[0];
        String space = infos[1];
        System.out.println("Statistiques sur le stockage des messages:");
        System.out.println("- nombre de message: " + nb);
        System.out.println("- espace disque: " + space + " octets");
    }
    
    /**
     * Collecte des emails du server 
     * @note ....
     * @use list pour afficher les messages
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void collect(String[] params) throws IOException, POP3Exception {
        System.out.println("Récupération ...\n");
        // retrieve all emails
        this.sendCommand("LIST");
        Response responseList = this.getResponseOrException();
        this.HM_messages = new HashMap<>();
        for (String line : responseList.getBodyLines()) {
            String[] words = line.split(" ");
            if (words.length != 2) {
                throw new POP3Exception("Une ligne de la liste de mail est mal formaté: " + line);
            }
            int id = Integer.valueOf(words[0]);
            int size = Integer.valueOf(words[1]);
            this.sendCommand("RETR " + id);
            Response responseRead = this.getResponseOrException();
            String body = responseRead.getBody();
            Message mess = new Message(id, size, body);
            this.HM_messages.put(id, mess);
        }
        // suppression des messages
        for (Message m : this.HM_messages.values()) {
            this.sendCommand("DELE " + m.getId());
            Response responseDel = this.getResponseOrException();
        }
        
        System.out.println("Nombre de message récupéré: " + responseList.getBodyLines().length);
    }
    
    /**
     * Liste tous les messages stockes en locale
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void list(String[] params) throws IOException, POP3Exception {
        if (this.HM_messages.isEmpty()) {
            System.out.println("Vous n'avez aucun message");
            System.out.println("Avez vous récupérez vos messages avec la commande \"collect\" ?");
        } else {
            String line = String.format("%-4s |  %-55s |  %-30s", "ID", "Émetteur", "Sujet");
            System.out.println(line);
        }
        for (Message m : this.HM_messages.values()) {
            String line = String.format("%-4s |  %-55s |  %-30s", m.getId(), m.getFrom(), m.getSubject());
            System.out.println(line);
        }
    }
    
    /**
     * Affichage du contenu des emails a partir de leur identifiant
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void read(String[] params) throws IOException, POP3Exception {
        if (params.length != 1) {
            throw new POP3Exception("Vous devez fournir le numéro du message à afficher");
        }
        int id = Integer.valueOf(params[0]);
        Message m = this.HM_messages.get(id);
        if (m != null) {
            System.out.println("Message: n°" + m.getId() + " (" + m.getSize() + " octets)");
            System.out.println(m.getRaw());
        } else {
            System.err.println("Le message n°" + id + " n'est pas disponible dans la base client");
            System.out.println("Avez vous récupérez vos messages avec la commande \"collect\" ?");
        }
    }
    
    /**
     * Quitter le POP3 client.
     * terminer la connexion tcp pre etablie
     * @param params
     * @throws IOException
     * @throws POP3Exception 
     */
    public void quit(String[] params) throws IOException, POP3Exception {
        System.out.println("Fermeture de la connexion ...");
        if (this.isConnected()) {
            System.out.println("terminaison POP3 ...");
            this.sendCommand("QUIT");
            Response response = this.getResponseOrException();
            System.out.println("terminaison TCP ...");
            this.disconnect();
        }
        System.out.println("\n       Au revoir !");
        System.exit(0);
    }
    
    /**
     * Deconnexion des sockets s'ils sont pas null
     */
    public void disconnect() throws IOException {
        if (this.isConnected()) {
            this.socket.close();
        }
    }
    
    /**
     * Connexion des sockets s'ils sont pas null
     * @return 
     */
    public boolean isConnected() {
        if (this.socket != null && this.socket.isConnected() && this.buf_netin != null && this.buf_netout != null) {
            return true;
        }
        
        return false;
    }
}
