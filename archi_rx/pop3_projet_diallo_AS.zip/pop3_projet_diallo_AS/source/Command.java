

/**
 * Commande et instruction pour le programme
 * commandes params1, params2 ...
 * @author Diallo Mohamed
 */
public class Command {
    private String str_action;
    private String[] tab_params;
    
    public Command(String str_action, String[] tab_params) {
        this.str_action = str_action;
        this.tab_params = tab_params;
    }
    
    public String getAction() {
        return this.str_action;
    }
    
    public String[] getParams() {
        return this.tab_params;
    }
    
    @Override
    public String toString() {
        return "Command " + this.str_action + ": " + tab_params;
    }
}
