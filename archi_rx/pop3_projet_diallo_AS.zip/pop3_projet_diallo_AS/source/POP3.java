
import java.util.concurrent.ThreadLocalRandom;
import java.util.*;

/**
 * Methode Principale 
 * @author Diallo Mohamed
 */
public class POP3 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

		  Date date = new Date();
		  String dat = date.toString();
		  System.out.println("\n");
		  System.out.println("(*********************************************************************)");
		  System.out.println("(*                                                                   *)");
		  System.out.println("(*                   Projet de Archi_Reseau                          *)");
		  System.out.println("(*                                                                   *)");
		  System.out.println("(*   Sujet : Client POP3                                             *)");
		  System.out.println("(*  Auteur : Diallo Mohamed                                          *)");
		  System.out.println("(*    Date : " + dat + "                            *)");
		  System.out.println("(*                                                                   *)");
		  System.out.println("(*                                  D.U.T informatique A.S 2017/2018 *)");
		  System.out.println("(*                                  IUT Charlemagne                  *)");
		  System.out.println("(*                                  Universite de Lorraine           *)");
		  System.out.println("(*                                                                   *)");
		  System.out.println("(*********************************************************************)");

        Client client = new Client();
        client.run();
    }
}
