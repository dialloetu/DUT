

import java.util.Arrays;
import java.util.regex.Pattern;

/**
 * Message reçu du serveur Pop3
 * @author Diallo Mohamed
 */
public class Message {
    private int identifiant;             // identifiant
    private int taille;           // taille de l'espace memoire
    // entete du message
    private String de;
    private String a;
    private String sujet;
    private String date;
    // Corps du message
    private String corps;        // message - entete
    private String raw;         // message = entete + corps
    
    // Patterns de l'entete du message
    public static Pattern fromPattern = Pattern.compile("^De: .*");
    public static Pattern toPattern = Pattern.compile("^A: .*");
    public static Pattern datePattern = Pattern.compile("^Date: .*");
    public static Pattern subjectPattern = Pattern.compile("^Sujet: .*");
    
    public Message(int identifiant, int taille, String raw) {
        this.identifiant = identifiant;
        this.taille = taille;
        this.raw = raw;
        
        String[] lignes = raw.split("\n");
        int i = 0;
        for (String ligne : lignes) {
            int entier = ligne.indexOf(" ")+1;
            i++;

            if (Pattern.matches(fromPattern.pattern(), ligne)) {
                this.de = ligne.substring(entier);
            } else if (Pattern.matches(toPattern.pattern(), ligne)) {
                this.a = ligne.substring(entier);
            } else if (Pattern.matches(datePattern.pattern(), ligne)) {
                this.date = ligne.substring(entier);
            } else if (Pattern.matches(subjectPattern.pattern(), ligne)) {
                this.sujet = ligne.substring(entier);
            } else {
                break;
            }
        }
        
        String[] corpsLignes = Arrays.copyOfRange(lignes, i, lignes.length);
        this.corps = Utils.textFromLines(corpsLignes);
    }
    
    public int getId() {
        return this.identifiant;
    }
    
    public int getSize() {
        return this.taille;
    }
    
    public String getFrom() {
        return this.de;
    }
    
    public String getTo() {
        return this.a;
    }
    
    public String getDate() {
        return this.date;
    }
    
    public String getSubject() {
        return this.sujet;
    }
    
    public String getBody() {
        return this.corps;
    }
    
    public String getRaw() {
        return this.raw;
    }
    
    /**
     * affichage pour l'utilisateur et/ou description
     * @return 
     */
    @Override
    public String toString() {
        StringBuilder construct = new StringBuilder("");
        construct.append("[").append(this.identifiant).append("] ");
        construct.append(this.sujet);
        construct.append("\nde ").append(this.de).append(" ");
        construct.append("à ").append(this.a);
        if (this.date != null && !this.date.isEmpty()) {
            construct.append("\nEnvoyé le: ").append(this.date);
        }
        construct.append("\nContenu:\n");
        construct.append(this.corps);
        
        return construct.toString();
    }
}
