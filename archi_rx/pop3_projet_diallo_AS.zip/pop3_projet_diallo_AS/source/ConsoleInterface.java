
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Interface en ligne de commande
 * utilisation d'un patterns pour la validation
 * @author Diallo Mohamed
 */
public class ConsoleInterface {
    private Scanner scanner;
    private String evenement;
    private ArrayList<Pattern> tab_de_patterns;
    
    public ConsoleInterface(ArrayList<Pattern> tab_de_patterns) {
        this(" > ", tab_de_patterns);
    }
    
    public ConsoleInterface(String evenement, ArrayList<Pattern> tab_de_patterns) {
        this.scanner = new Scanner(System.in);
        this.tab_de_patterns = tab_de_patterns;
        this.evenement = evenement;
    }
    
    /**
     * Retourne que la commande est bien valide (action/params)
     * @return 
     */
    public Command getCommand() {
        String ligne = "";
        System.err.println("");
        System.out.println("");
        boolean valide = false;
        do {
            System.out.print(this.evenement);
            ligne = this.scanner.nextLine();
            valide = this.match(ligne);        
            if (!valide) {
                System.err.println("Commande non reconnue (utiliser la commande help)");
            }
        } while (!valide);       
        return this.split(ligne);
    }
    
    /**
     * Test si une ligne correspond au pattern
     * @param ligne
     * @return true sur une correspondance
     */
    public boolean match(String ligne) {
        for (Pattern pattern : this.tab_de_patterns ) {
            if (Pattern.matches(pattern.pattern(), ligne)) {
                return true;
            }
        }       
        return false;
    }
    
    /**
     * Split une ligne et l'action params (optionnel)
     * @param ligne
     * @return 
     */
    public Command split(String ligne) {
        String[] args = ligne.split(" ");
        String action = args[0];
        String[] params = Arrays.copyOfRange(args, 1, args.length);       
        Command command = new Command(action, params);       
        return command;
    }
} 
